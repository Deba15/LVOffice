package com.example.officeeditor

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// ======================= WORD =======================

@Composable
fun DocxEditor(doc: DocxDocument, onChange: () -> Unit) {
    val texts = remember(doc) { doc.texts().toMutableStateList() }
    fun resync() {
        texts.clear()
        texts.addAll(doc.texts())
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        itemsIndexed(texts) { i, text ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = text,
                    onValueChange = {
                        texts[i] = it
                        doc.setText(i, it)
                        onChange()
                    },
                    label = { Text("${i + 1}. bekezdés") },
                    modifier = Modifier.weight(1f)
                )
                Column {
                    IconButton(onClick = { doc.insertAfter(i); resync(); onChange() }) {
                        Icon(Icons.Default.Add, contentDescription = "Új bekezdés utána")
                    }
                    IconButton(onClick = { doc.remove(i); resync(); onChange() }) {
                        Icon(Icons.Default.Delete, contentDescription = "Bekezdés törlése")
                    }
                }
            }
        }
    }
}

// ======================= EXCEL =======================

private val CELL_W = 96.dp
private val CELL_H = 36.dp
private val HEAD_W = 44.dp

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun XlsxEditor(book: XlsxWorkbook, onChange: () -> Unit, onMessage: (String) -> Unit) {
    var sheetIdx by remember(book) { mutableIntStateOf(0) }
    var version by remember(book) { mutableIntStateOf(0) }       // újraolvasás jelzése
    var editing by remember { mutableStateOf<CellRef?>(null) }

    val cells = remember(book, sheetIdx, version) { book.readCells(sheetIdx) }
    val rowCount = maxOf((cells.keys.maxOfOrNull { it.row } ?: -1) + 21, 50)
    val colCount = maxOf((cells.keys.maxOfOrNull { it.col } ?: -1) + 4, 10)

    Column(Modifier.fillMaxSize()) {
        if (book.sheets.size > 1) {
            ScrollableTabRow(selectedTabIndex = sheetIdx, edgePadding = 8.dp) {
                book.sheets.forEachIndexed { i, sheet ->
                    Tab(selected = i == sheetIdx, onClick = { sheetIdx = i }, text = { Text(sheet.name) })
                }
            }
        }
        Box(Modifier.fillMaxSize().horizontalScroll(rememberScrollState())) {
            LazyColumn(Modifier.width(HEAD_W + CELL_W * colCount).fillMaxHeight()) {
                stickyHeader {
                    Row {
                        HeaderCell("", HEAD_W)
                        for (c in 0 until colCount) HeaderCell(columnName(c), CELL_W)
                    }
                }
                items(rowCount) { r ->
                    Row {
                        HeaderCell("${r + 1}", HEAD_W)
                        for (c in 0 until colCount) {
                            val ref = CellRef(r, c)
                            DataCell(cells[ref].orEmpty()) { editing = ref }
                        }
                    }
                }
            }
        }
    }

    editing?.let { ref ->
        val initial = cells[ref].orEmpty()
        CellEditDialog(
            ref = ref,
            initial = initial,
            formula = book.formulaAt(sheetIdx, ref),
            onDismiss = { editing = null },
            onSave = { value ->
                editing = null
                if (value != initial) {
                    val error = book.setCell(sheetIdx, ref, value)
                    if (error != null) onMessage(error) else { version++; onChange() }
                }
            }
        )
    }
}

@Composable
private fun HeaderCell(text: String, width: Dp) {
    Box(
        Modifier.width(width).height(CELL_H)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
        contentAlignment = Alignment.Center
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun DataCell(text: String, onClick: () -> Unit) {
    Box(
        Modifier.width(CELL_W).height(CELL_H)
            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(text, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun CellEditDialog(
    ref: CellRef,
    initial: String,
    formula: String?,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var value by remember(ref) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${ref.name} cella") },
        text = {
            Column {
                if (formula != null) {
                    Text(
                        "Képlet: =$formula\nHa átírod, az érték felülírja a képletet.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedTextField(value = value, onValueChange = { value = it }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { TextButton(onClick = { onSave(value) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Mégse") } }
    )
}
