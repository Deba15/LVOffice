package com.example.officeeditor

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.OutputStream

const val MIME_DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
const val MIME_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

/** Egy megnyitott dokumentum tartalma (Word vagy Excel). */
sealed interface OfficeContent {
    fun save(out: OutputStream)
}

data class OpenFile(val uri: Uri, val name: String, val content: OfficeContent)

object FileLoader {
    fun open(context: Context, uri: Uri): OpenFile {
        val entries = context.contentResolver.openInputStream(uri)?.use { OfficeZip.read(it) }
            ?: error("A fájl nem olvasható")
        // A tartalom alapján döntünk, nem a kiterjesztés alapján
        val content: OfficeContent = when {
            "word/document.xml" in entries -> DocxDocument(entries)
            "xl/workbook.xml" in entries -> XlsxWorkbook(entries)
            else -> error("Nem támogatott formátum – csak .docx és .xlsx (a régi .doc/.xls nem)")
        }
        return OpenFile(uri, displayName(context, uri) ?: "dokumentum", content)
    }

    fun displayName(context: Context, uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val startUri = intent?.data   // ha fájlkezelőből "Megnyitás ezzel..." indították
        setContent {
            val colors = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            MaterialTheme(colorScheme = colors) {
                OfficeApp(startUri)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfficeApp(startUri: Uri?) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var file by remember { mutableStateOf<OpenFile?>(null) }
    var dirty by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    fun notify(msg: String) {
        scope.launch { snackbar.showSnackbar(msg) }
    }

    fun load(uri: Uri) {
        busy = true
        scope.launch {
            try {
                file = withContext(Dispatchers.IO) { FileLoader.open(context, uri) }
                dirty = false
            } catch (e: Exception) {
                notify("Nem sikerült megnyitni: ${e.message}")
            } finally {
                busy = false
            }
        }
    }

    fun saveTo(target: Uri) {
        val f = file ?: return
        busy = true
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val out = context.contentResolver.openOutputStream(target, "wt")
                        ?: error("A cél nem írható")
                    out.use { f.content.save(it) }
                }
                file = f.copy(uri = target, name = FileLoader.displayName(context, target) ?: f.name)
                dirty = false
                notify("Mentve ✓")
            } catch (e: Exception) {
                notify("Mentés sikertelen (${e.message}). Próbáld a „Mentés másként” lehetőséget.")
            } finally {
                busy = false
            }
        }
    }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            load(uri)
        }
    }
    val saveDocxAs = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(MIME_DOCX)) { uri ->
        if (uri != null) saveTo(uri)
    }
    val saveXlsxAs = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(MIME_XLSX)) { uri ->
        if (uri != null) saveTo(uri)
    }

    fun openPicker() = openLauncher.launch(arrayOf(MIME_DOCX, MIME_XLSX))
    fun saveAs() {
        val f = file ?: return
        if (f.content is DocxDocument) saveDocxAs.launch(f.name) else saveXlsxAs.launch(f.name)
    }

    LaunchedEffect(startUri) {
        if (startUri != null) load(startUri)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = file?.let { (if (dirty) "● " else "") + it.name } ?: "LV Office",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                actions = {
                    val f = file
                    if (f != null) {
                        TextButton(onClick = { saveTo(f.uri) }, enabled = !busy) { Text("Mentés") }
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Menü")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Megnyitás…") },
                                onClick = { menuOpen = false; openPicker() }
                            )
                            if (f != null) {
                                DropdownMenuItem(
                                    text = { Text("Mentés másként…") },
                                    onClick = { menuOpen = false; saveAs() }
                                )
                            }
                        }
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            when (val content = file?.content) {
                null -> EmptyState(onOpen = ::openPicker)
                is DocxDocument -> DocxEditor(content, onChange = { dirty = true })
                is XlsxWorkbook -> XlsxEditor(content, onChange = { dirty = true }, onMessage = ::notify)
            }
        }
    }
}

@Composable
private fun EmptyState(onOpen: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Nyiss meg egy Word (.docx) vagy Excel (.xlsx) fájlt.", textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onOpen) { Text("Fájl megnyitása") }
    }
}
