package com.example.officeeditor

import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.OutputStream

/**
 * Word (.docx) dokumentum bekezdésenkénti szerkesztése.
 * Csak a word/document.xml-t módosítja, minden más (képek, stílusok, fejléc...) érintetlen marad.
 * A bekezdés formázása megmarad; szerkesztéskor a szöveg az első szövegrész (run) formázását kapja.
 */
class DocxDocument(private val entries: LinkedHashMap<String, ByteArray>) : OfficeContent {

    private val xml = OfficeZip.parseXml(entries[PART] ?: error("Hiányzik a $PART"))
    private val w = xml.documentElement.tagPrefix          // általában "w"
    private fun n(local: String) = qualified(w, local)

    private val body: Element = xml.byTag(n("body")).firstOrNull() ?: error("Hibás DOCX: nincs body")
    private val paragraphs: MutableList<Element> = xml.byTag(n("p")).toMutableList()

    init {
        if (paragraphs.isEmpty()) {
            val p = xml.createElement(n("p"))
            body.insertBefore(p, body.children(n("sectPr")).lastOrNull())
            paragraphs.add(p)
        }
    }

    fun texts(): List<String> = paragraphs.map { readText(it) }

    private fun readText(p: Element): String {
        val sb = StringBuilder()
        fun walk(node: Node) {
            for (child in node.childElements()) {
                when (child.tagName) {
                    n("p"), n("pPr"), n("rPr") -> Unit           // beágyazott bekezdés / formázás: kihagyjuk
                    n("t") -> sb.append(child.textContent)
                    n("tab") -> sb.append('\t')
                    n("br"), n("cr") -> if (isLineBreak(child)) sb.append('\n')
                    else -> walk(child)
                }
            }
        }
        walk(p)
        return sb.toString()
    }

    private fun isLineBreak(e: Element): Boolean =
        e.tagName == n("cr") ||
            (e.tagName == n("br") && e.getAttribute(n("type")).let { it.isEmpty() || it == "textWrapping" })

    /** A bekezdés saját elemei (a beágyazott, pl. szövegdobozban lévő bekezdések nélkül). */
    private fun owned(p: Element, local: String): List<Element> =
        p.byTag(n(local)).filter { nearestParagraph(it) === p }

    private fun nearestParagraph(e: Element): Element? {
        var node: Node? = e.parentNode
        while (node != null) {
            if (node is Element && node.tagName == n("p")) return node
            node = node.parentNode
        }
        return null
    }

    fun setText(index: Int, text: String) {
        val p = paragraphs[index]
        // régi tabulátorok / sortörések törlése a szövegrészekből
        (owned(p, "tab") + owned(p, "br").filter(::isLineBreak) + owned(p, "cr"))
            .filter { it.parentNode is Element && (it.parentNode as Element).tagName == n("r") }
            .forEach { it.parentNode.removeChild(it) }

        val ts = owned(p, "t")
        ts.drop(1).forEach { it.parentNode.removeChild(it) }
        val first = ts.firstOrNull() ?: newTextElement(p)
        val run = first.parentNode

        val lines = text.split('\n')
        setT(first, lines[0])
        var anchor: Node = first
        for (line in lines.drop(1)) {
            val br = xml.createElement(n("br"))
            run.insertBefore(br, anchor.nextSibling); anchor = br
            val t = xml.createElement(n("t"))
            setT(t, line)
            run.insertBefore(t, anchor.nextSibling); anchor = t
        }
    }

    private fun setT(t: Element, s: String) {
        t.textContent = s
        t.setAttribute("xml:space", "preserve")
    }

    private fun newTextElement(p: Element): Element {
        val run = owned(p, "r").firstOrNull()
            ?: xml.createElement(n("r")).also { p.appendChild(it) }
        return xml.createElement(n("t")).also { run.appendChild(it) }
    }

    /** Új üres bekezdés a megadott után, ugyanazzal a bekezdés-formázással (stílus, lista stb.). */
    fun insertAfter(index: Int) {
        val src = paragraphs[index]
        val p = xml.createElement(n("p"))
        src.children(n("pPr")).firstOrNull()?.let { pPr ->
            val copy = pPr.cloneNode(true) as Element
            copy.children(n("sectPr")).forEach { copy.removeChild(it) }   // szakasztörést nem másolunk
            p.appendChild(copy)
        }
        src.parentNode.insertBefore(p, src.nextSibling)
        paragraphs.add(index + 1, p)
    }

    /** Bekezdés törlése; ha ez nem biztonságos (pl. utolsó a táblázatcellában), csak kiüríti. */
    fun remove(index: Int) {
        val p = paragraphs[index]
        val parent = p.parentNode as Element
        val holdsSection = owned(p, "sectPr").isNotEmpty()
        val lastInCell = parent.tagName == n("tc") && parent.children(n("p")).size <= 1
        if (holdsSection || lastInCell || paragraphs.size <= 1) {
            setText(index, "")
            return
        }
        parent.removeChild(p)
        // a törölt bekezdésben lévő beágyazott bekezdéseket is kivesszük a listából
        paragraphs.removeAll { it === p || isInside(it, p) }
    }

    private fun isInside(e: Node, ancestor: Node): Boolean {
        var node: Node? = e.parentNode
        while (node != null) {
            if (node === ancestor) return true
            node = node.parentNode
        }
        return false
    }

    override fun save(out: OutputStream) {
        entries[PART] = OfficeZip.toBytes(xml)
        OfficeZip.write(entries, out)
    }

    private companion object {
        const val PART = "word/document.xml"
    }
}
