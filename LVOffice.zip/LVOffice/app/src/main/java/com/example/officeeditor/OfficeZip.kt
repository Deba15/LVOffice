package com.example.officeeditor

import org.w3c.dom.Attr
import org.w3c.dom.CDATASection
import org.w3c.dom.Comment
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import org.w3c.dom.NodeList
import org.w3c.dom.ProcessingInstruction
import org.w3c.dom.Text
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.xml.parsers.DocumentBuilderFactory

/**
 * A .docx és .xlsx fájl valójában egy ZIP, benne XML fájlokkal.
 * Ez az objektum olvassa be / írja ki a ZIP-et és az XML-eket.
 */
object OfficeZip {

    fun read(input: InputStream): LinkedHashMap<String, ByteArray> {
        val entries = LinkedHashMap<String, ByteArray>()   // megőrzi a sorrendet
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) entries[entry.name] = zip.readBytes()
                entry = zip.nextEntry
            }
        }
        return entries
    }

    fun write(entries: Map<String, ByteArray>, out: OutputStream) {
        val zip = ZipOutputStream(out)
        for ((name, data) in entries) {
            zip.putNextEntry(ZipEntry(name))
            zip.write(data)
            zip.closeEntry()
        }
        zip.finish()
        zip.flush()
    }

    /** Névtér-érzékelés NÉLKÜL olvasunk, így az xmlns attribútumok sima attribútumként megmaradnak. */
    fun parseXml(bytes: ByteArray): Document {
        val factory = DocumentBuilderFactory.newInstance()
        factory.isNamespaceAware = false
        return factory.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
    }

    /** Saját, egyszerű XML-író: kiszámítható kimenet minden Android verzión. */
    fun toBytes(doc: Document): ByteArray {
        val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\r\n")
        for (child in doc.childNodes.nodes()) writeNode(child, sb)
        return sb.toString().toByteArray(Charsets.UTF_8)
    }

    private fun writeNode(node: Node, sb: StringBuilder) {
        when (node) {
            is Element -> {
                sb.append('<').append(node.tagName)
                val attrs = node.attributes
                for (i in 0 until attrs.length) {
                    val a = attrs.item(i) as Attr
                    sb.append(' ').append(a.name).append("=\"")
                    escape(a.value, sb, attribute = true)
                    sb.append('"')
                }
                if (!node.hasChildNodes()) {
                    sb.append("/>")
                } else {
                    sb.append('>')
                    for (child in node.childNodes.nodes()) writeNode(child, sb)
                    sb.append("</").append(node.tagName).append('>')
                }
            }
            is CDATASection -> sb.append("<![CDATA[").append(node.data).append("]]>")
            is Text -> escape(node.data, sb, attribute = false)
            is Comment -> sb.append("<!--").append(node.data).append("-->")
            is ProcessingInstruction -> sb.append("<?").append(node.target).append(' ').append(node.data).append("?>")
        }
    }

    private fun escape(s: String, sb: StringBuilder, attribute: Boolean) {
        for (ch in s) {
            when (ch) {
                '&' -> sb.append("&amp;")
                '<' -> sb.append("&lt;")
                '>' -> sb.append("&gt;")
                '"' -> if (attribute) sb.append("&quot;") else sb.append(ch)
                '\n' -> if (attribute) sb.append("&#10;") else sb.append(ch)
                '\r' -> sb.append("&#13;")
                '\t' -> if (attribute) sb.append("&#9;") else sb.append(ch)
                else -> sb.append(ch)
            }
        }
    }
}

// ---- Kis segédfüggvények a DOM-hoz ----

fun NodeList.nodes(): List<Node> = (0 until length).map { item(it) }
fun NodeList.elements(): List<Element> = nodes().filterIsInstance<Element>()
fun Node.childElements(): List<Element> = childNodes.elements()
fun Element.children(tag: String): List<Element> = childElements().filter { it.tagName == tag }
fun Document.byTag(tag: String): List<Element> = getElementsByTagName(tag).elements()
fun Element.byTag(tag: String): List<Element> = getElementsByTagName(tag).elements()

/** Elemek a névtér-előtagtól függetlenül (pl. "Relationship" vagy "x:Relationship"). */
fun Document.byLocalName(local: String): List<Element> =
    getElementsByTagName("*").elements().filter { it.tagName.substringAfter(':') == local }

/** "w:document" -> "w", "worksheet" -> "" */
val Element.tagPrefix: String get() = if (':' in tagName) tagName.substringBefore(':') else ""

fun qualified(prefix: String, local: String) = if (prefix.isEmpty()) local else "$prefix:$local"
