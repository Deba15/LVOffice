package com.example.officeeditor

import org.w3c.dom.Attr
import org.w3c.dom.Document
import org.w3c.dom.Element
import java.io.OutputStream

data class CellRef(val row: Int, val col: Int) {        // mindkettő 0-tól számozva
    val name: String get() = columnName(col) + (row + 1)

    companion object {
        private val PATTERN = Regex("^\\$?([A-Z]+)\\$?(\\d+)$")
        fun parse(s: String): CellRef? {
            val m = PATTERN.matchEntire(s.uppercase()) ?: return null
            val col = m.groupValues[1].fold(0) { acc, c -> acc * 26 + (c - 'A' + 1) } - 1
            val row = m.groupValues[2].toIntOrNull()?.minus(1) ?: return null
            return CellRef(row, col)
        }
    }
}

/** 0 -> A, 25 -> Z, 26 -> AA ... */
fun columnName(col: Int): String {
    var n = col + 1
    val sb = StringBuilder()
    while (n > 0) {
        val r = (n - 1) % 26
        sb.append('A' + r)
        n = (n - 1) / 26
    }
    return sb.reverse().toString()
}

/**
 * Excel (.xlsx) munkafüzet cellánkénti szerkesztése.
 * Csak a módosított munkalapokat írja újra; a stílusok, diagramok stb. megmaradnak.
 */
class XlsxWorkbook(private val entries: LinkedHashMap<String, ByteArray>) : OfficeContent {

    class Sheet(val name: String, val path: String, val xml: Document) {
        private val prefix = xml.documentElement.tagPrefix
        fun n(local: String) = qualified(prefix, local)
    }

    private val workbookXml = OfficeZip.parseXml(entries[WORKBOOK] ?: error("Hiányzik a $WORKBOOK"))

    private val sharedStrings: List<String> = entries["xl/sharedStrings.xml"]?.let { bytes ->
        val doc = OfficeZip.parseXml(bytes)
        val n = { l: String -> qualified(doc.documentElement.tagPrefix, l) }
        doc.byTag(n("si")).map { si ->
            si.byTag(n("t")).filter { (it.parentNode as Element).tagName != n("rPh") }
                .joinToString("") { it.textContent }
        }
    } ?: emptyList()

    val sheets: List<Sheet>
    private val modified = mutableSetOf<Sheet>()

    init {
        val relsBytes = entries[WORKBOOK_RELS] ?: error("Hibás XLSX: hiányzik a $WORKBOOK_RELS")
        val targets = OfficeZip.parseXml(relsBytes).byLocalName("Relationship")
            .associate { it.getAttribute("Id") to it.getAttribute("Target") }
        val wb = { l: String -> qualified(workbookXml.documentElement.tagPrefix, l) }

        sheets = workbookXml.byTag(wb("sheet")).mapNotNull { s ->
            val rid = (0 until s.attributes.length).map { s.attributes.item(it) as Attr }
                .firstOrNull { it.name.endsWith(":id") }?.value ?: return@mapNotNull null
            val target = targets[rid] ?: return@mapNotNull null
            val path = if (target.startsWith("/")) target.removePrefix("/") else "xl/$target"
            val xml = OfficeZip.parseXml(entries[path] ?: return@mapNotNull null)
            val sheet = Sheet(s.getAttribute("name"), path, xml)
            if (xml.byTag(sheet.n("sheetData")).isEmpty()) null else sheet   // pl. diagramlap
        }
        if (sheets.isEmpty()) error("Nincs szerkeszthető munkalap a fájlban")
    }

    fun readCells(sheetIndex: Int): Map<CellRef, String> {
        val s = sheets[sheetIndex]
        val result = HashMap<CellRef, String>()
        for (c in s.xml.byTag(s.n("c"))) {
            val ref = CellRef.parse(c.getAttribute("r")) ?: continue
            val text = cellText(s, c)
            if (text.isNotEmpty()) result[ref] = text
        }
        return result
    }

    private fun cellText(s: Sheet, c: Element): String {
        val v = c.children(s.n("v")).firstOrNull()?.textContent
        return when (c.getAttribute("t")) {
            "s" -> v?.trim()?.toIntOrNull()?.let { sharedStrings.getOrNull(it) } ?: ""
            "inlineStr" -> c.children(s.n("is")).firstOrNull()?.byTag(s.n("t"))
                ?.filter { (it.parentNode as Element).tagName != s.n("rPh") }
                ?.joinToString("") { it.textContent } ?: ""
            "b" -> if (v == "1") "IGAZ" else "HAMIS"
            else -> v ?: ""
        }
    }

    private fun findCell(s: Sheet, ref: CellRef): Element? =
        s.xml.byTag(s.n("c")).firstOrNull { CellRef.parse(it.getAttribute("r")) == ref }

    fun formulaAt(sheetIndex: Int, ref: CellRef): String? {
        val s = sheets[sheetIndex]
        return findCell(s, ref)?.children(s.n("f"))?.firstOrNull()?.textContent?.takeIf { it.isNotEmpty() }
    }

    /** Cella beírása. Hibánál a hibaüzenetet adja vissza, sikernél null-t. */
    fun setCell(sheetIndex: Int, ref: CellRef, text: String): String? {
        val s = sheets[sheetIndex]
        val doc = s.xml
        val sheetData = doc.byTag(s.n("sheetData")).first()
        val rowNum = ref.row + 1

        val rows = sheetData.children(s.n("row"))
        var row = rows.firstOrNull { it.getAttribute("r").toIntOrNull() == rowNum }
        if (row == null) {
            if (text.isEmpty()) return null
            row = doc.createElement(s.n("row"))
            row.setAttribute("r", rowNum.toString())
            sheetData.insertBefore(row, rows.firstOrNull { (it.getAttribute("r").toIntOrNull() ?: 0) > rowNum })
        }

        val cells = row.children(s.n("c"))
        var cell = cells.firstOrNull { CellRef.parse(it.getAttribute("r")) == ref }
        if (cell == null) {
            if (text.isEmpty()) return null
            cell = doc.createElement(s.n("c"))
            cell.setAttribute("r", ref.name)
            row.insertBefore(cell, cells.firstOrNull { (CellRef.parse(it.getAttribute("r"))?.col ?: -1) > ref.col })
        }

        // Megosztott/tömb képlet forráscelláját nem bántjuk, mert más cellák is ráépülnek
        val f = cell.children(s.n("f")).firstOrNull()
        if (f != null && f.hasAttribute("ref")) {
            return "A(z) ${ref.name} egy több cellára érvényes képlet forrása, ezt itt nem lehet felülírni."
        }

        row.removeAttribute("spans")
        cell.childElements()
            .filter { it.tagName == s.n("f") || it.tagName == s.n("v") || it.tagName == s.n("is") }
            .forEach { cell.removeChild(it) }
        cell.removeAttribute("t")

        val trimmed = text.trim()
        when {
            trimmed.isEmpty() -> Unit
            NUMBER.matches(trimmed) -> addValue(s, cell, trimmed.replace(',', '.'))
            trimmed.uppercase() in setOf("IGAZ", "TRUE") -> { cell.setAttribute("t", "b"); addValue(s, cell, "1") }
            trimmed.uppercase() in setOf("HAMIS", "FALSE") -> { cell.setAttribute("t", "b"); addValue(s, cell, "0") }
            else -> {
                cell.setAttribute("t", "inlineStr")
                val isEl = doc.createElement(s.n("is"))
                val t = doc.createElement(s.n("t"))
                t.setAttribute("xml:space", "preserve")
                t.textContent = text
                isEl.appendChild(t)
                cell.appendChild(isEl)
            }
        }
        modified += s
        return null
    }

    private fun addValue(s: Sheet, cell: Element, value: String) {
        val v = s.xml.createElement(s.n("v"))
        v.textContent = value
        cell.appendChild(v)
    }

    override fun save(out: OutputStream) {
        if (modified.isNotEmpty()) {
            for (s in modified) {
                s.xml.byTag(s.n("dimension")).forEach { it.parentNode.removeChild(it) }  // elavult méretadat
                entries[s.path] = OfficeZip.toBytes(s.xml)
            }
            dropCalcChain()
            forceRecalculation()
            entries[WORKBOOK] = OfficeZip.toBytes(workbookXml)
        }
        OfficeZip.write(entries, out)
    }

    /** A képlet-számítási lánc elavulhat, ezért töröljük; az Excel újraépíti. */
    private fun dropCalcChain() {
        if (entries.remove("xl/calcChain.xml") == null) return
        entries[CONTENT_TYPES]?.let { bytes ->
            val d = OfficeZip.parseXml(bytes)
            d.byLocalName("Override").filter { it.getAttribute("PartName") == "/xl/calcChain.xml" }
                .forEach { it.parentNode.removeChild(it) }
            entries[CONTENT_TYPES] = OfficeZip.toBytes(d)
        }
        entries[WORKBOOK_RELS]?.let { bytes ->
            val d = OfficeZip.parseXml(bytes)
            d.byLocalName("Relationship").filter { it.getAttribute("Target").endsWith("calcChain.xml") }
                .forEach { it.parentNode.removeChild(it) }
            entries[WORKBOOK_RELS] = OfficeZip.toBytes(d)
        }
    }

    /** Megnyitáskor számolja újra a képleteket, hogy a módosított cellák hatása látszódjon. */
    private fun forceRecalculation() {
        val root = workbookXml.documentElement
        val n = { l: String -> qualified(root.tagPrefix, l) }
        val calcPr = root.children(n("calcPr")).firstOrNull() ?: run {
            // a sémában a calcPr ezek után az elemek után következik
            val before = setOf(n("sheets"), n("functionGroups"), n("externalReferences"), n("definedNames"))
            val after = root.childElements().lastOrNull { it.tagName in before } ?: return
            workbookXml.createElement(n("calcPr")).also { root.insertBefore(it, after.nextSibling) }
        }
        calcPr.setAttribute("fullCalcOnLoad", "1")
    }

    private companion object {
        const val WORKBOOK = "xl/workbook.xml"
        const val WORKBOOK_RELS = "xl/_rels/workbook.xml.rels"
        const val CONTENT_TYPES = "[Content_Types].xml"
        val NUMBER = Regex("^-?\\d+([.,]\\d+)?([eE][+-]?\\d+)?$")
    }
}
