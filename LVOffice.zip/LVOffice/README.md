# LV Office (Android)

Egyszerű Android app Word (.docx) és Excel (.xlsx) fájlok megnyitására és szerkesztésére.
Kotlin + Jetpack Compose, külső Office-könyvtár nélkül (a fájlokat közvetlenül, ZIP + XML-ként kezeli).

## Mit tud
- **Word:** bekezdésenkénti szövegszerkesztés, új bekezdés beszúrása (a formázás öröklődik), törlés.
  Képek, stílusok, fejléc/lábléc, táblázatok szerkezete megmarad.
- **Excel:** táblázatos nézet, több munkalap, cella szerkesztése koppintással
  (szám – tizedesvesszővel is –, szöveg, IGAZ/HAMIS). Mentés után a képleteket az Excel újraszámolja.
- Megnyitás a fájlválasztóból vagy fájlkezelőből ("Megnyitás ezzel…"), Mentés / Mentés másként.

## Fordítás
1. Telepítsd az [Android Studio](https://developer.android.com/studio)-t.
2. *File → Open* → válaszd ki ezt a mappát; várd meg a Gradle szinkront.
3. Telefon USB-n (fejlesztői mód + USB hibakeresés) → ▶ Run.
   APK-hoz: *Build → Build App Bundle(s)/APK(s) → Build APK(s)*.

## Korlátok (bővítési ötletek)
- Nincs karakterformázás (félkövér, betűméret) – szerkesztéskor a bekezdés az első szövegrész formázását kapja.
- Régi .doc/.xls és .pptx nem támogatott.
- Excelben a dátumok sorszámként látszanak, képletet nem lehet beírni, csak értéket.
- Szövegdobozok, nyomon követett változtatások csak korlátozottan.

Komolyabb funkciókhoz (formázás, PDF-export) érdemes az Apache POI-t vagy egy
WebView + JS szerkesztőt bevonni.
